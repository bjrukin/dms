<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * PROJECT
 *
 * PACKAGE DESCRIPTION
 *
 * @package         PROJECT
 * @author          <AUTHOR_NAME>
 * @copyright       Copyright (c) 2016
 */

// ---------------------------------------------------------------------------

/** @defgroup module_project_controller Project Controller Module
 * \brief Master Module for Project Controller
 * \details This module is used for managing data as master records for taxable and non taxable item of different project controller
 */

/**
 * @addtogroup module_project_controller 
 * @{
 */

/**
 * \class Project Controller
 * \brief Controller Class for managing master items of different project controller 
 */

/**
 *@}
 */

class Project_Controller extends Admin_Controller {

    /**
    *
    * Constructor of Project_Contoller Controller
    *
    * @access  public
    * @param   null
    */
	public function __construct()
    {
		parent::__construct();
	}

    /**
    *
    * Search in index page
    *
    * @access  public
    * @param   null
    * @return  null
    */
	public function _get_search_param()
    {
    	//search_params helper (project_helper);
		search_params();
	}

    public function get_groups_combo_json() 
    {
        $this->load->model('groups/group_model');

        // $this->db->where_not_in('id', array(1,2));
        $current_user_groups = $this->aauth->get_user_groups();
        if(isset($current_user_groups[1])) {
            $this->db->where('id >', $current_user_groups[1]->group_id);
        }

        $this->group_model->order_by('name asc');
        
        $rows=$this->group_model->findAll(null, array('id','name'));

        array_unshift($rows, array('id' => '0', 'name' => 'Select Group'));

        echo json_encode($rows);
        exit;
    }

    public function get_districts_combo_json() 
    {
        $filename = CACHE_PATH . 'districts.json';

        if (file_exists($filename)) {
            echo file_get_contents($filename);
            exit;
        }

        /*$this->load->model('district_mvs/district_mv_model');

        $this->db->where('type', 'DISTRICT');

        $this->district_mv_model->_table = 'view_district_mvs';
        $this->district_mv_model->order_by('name asc');
        
        $rows=$this->district_mv_model->findAll(null, array('id','name'));

        array_unshift($rows, array('id' => '0', 'name' => 'Select District'));

        echo json_encode($rows);*/
    }

    public function get_mun_vdcs_combo_json() 
    {
        $mun_vdc_id = $this->input->get('parent_id');

        $filename = CACHE_PATH . "mun_vdc_{$mun_vdc_id}.json";

        if (file_exists($filename)) {
            echo file_get_contents($filename);
            exit;
        }
    }

    public function get_cities_combo_json() 
    {
        $mun_vdc_id = $this->input->get('mun_vdc_id');

        $filename = CACHE_PATH . "city_places_{$mun_vdc_id}.json";

        if (file_exists($filename)) {
            echo file_get_contents($filename);
            exit;
        }
    }

    public function get_master_combo_json() 
    {
        $table_name = $this->input->get('table_name');

        $filename = CACHE_PATH . "{$table_name}.json";

        if (file_exists($filename)) {
            echo file_get_contents($filename);
            exit;
        }
    }

    public function get_dealers_combo_json() 
    {
        $this->load->model('dealers/dealer_model');

        $this->dealer_model->order_by('name asc');

         // ACCESS LEVEL CHECK STARTS
        $is_showroom_incharge = NULL;
        $is_sales_executive = NULL;
    
        $dealer_list    = (is_dealer_incharge()) ? get_dealer_list() : NULL; 
        
        if (empty($dealer_list)) {
            $is_showroom_incharge = (is_showroom_incharge()) ? TRUE : NULL; 
            $is_sales_executive = (is_sales_executive()) ? TRUE : NULL; 
        }
        
        if(!empty($dealer_list)) {
            $this->db->where_in('id', $dealer_list);
        } elseif ($is_showroom_incharge) {
            $this->db->where('id', $this->session->userdata('employee')['dealer_id']);
        }
        
        $rows=$this->dealer_model->findAll(null, array('id','name'));

        array_unshift($rows, array('id' => '0', 'name' => 'Select Dealer'));

        echo json_encode($rows);
    }

    public function get_executives_combo_json() 
    {
        $this->load->model('employees/employee_model');

        $this->employee_model->order_by('name asc');

        if($this->input->get('dealer_id')){
            $this->db->where('dealer_id', $this->input->get('dealer_id'));
        }

        $fields = array();
        $fields[] = 'id';
        $fields[] = "CASE WHEN middle_name <> '' THEN first_name || ' ' || middle_name || ' ' || last_name ELSE first_name || ' ' || last_name END as name ";
        
        $rows=$this->employee_model->findAll(null, $fields);

        array_unshift($rows, array('id' => '0', 'name' => 'Select Executive'));

        echo json_encode($rows);
    }

    public function get_variants_combo_json() 
    {
        $vehicle_id = $this->input->get('vehicle_id');

        $this->load->model('vehicles/vehicle_model');

        $this->vehicle_model->_table = 'view_dms_vehicles';

        $this->db->where('vehicle_id', $vehicle_id);

        $this->db->group_by('1,2,3');
        
        $rows=$this->vehicle_model->findAll(null, array('vehicle_id','variant_id', 'variant_name'));

        array_unshift($rows, array('variant_id' => '0', 'variant_name' => 'Select Variant'));

        echo json_encode($rows);
    }

    public function get_dealer_events_combo_json() 
    {
        $dealer_id = $this->input->get('dealer_id');

        $this->load->model('events/event_model');

        $this->db->where_in('dealer_id', array(0,$dealer_id));

        //$this->db->where('start_date_en >=', date('Y-m-d'));

        $rows=$this->event_model->findAll(null, array('id','name'));

        echo json_encode($rows);
    }

    public function get_colors_combo_json() 
    {
        $vehicle_id = $this->input->get('vehicle_id');
        $variant_id = $this->input->get('variant_id');

        $this->load->model('vehicles/vehicle_model');

        $this->vehicle_model->_table = 'view_dms_vehicles';

        $this->db->where('vehicle_id', $vehicle_id);
        $this->db->where('variant_id', $variant_id);

        $rows=$this->vehicle_model->findAll(null, array('color_id','color_name'));
        
        array_unshift($rows, array('color_id' => '0', 'color_name' => 'Select Color'));

        echo json_encode($rows);
    }

    public function get_dealer_incharges_combo_json() 
    {
        $this->load->model('users/user_model');

        $this->user_model->_table = 'view_user_groups';

        $this->db->where('group_id', DEALER_INCHARGE_GROUP);
        
        $rows=$this->user_model->findAll(null, array('user_id',"(fullname || ' [' || username || ']') as username"));

        array_unshift($rows, array('id' => '0', 'username' => 'Select Incharge'));

        echo json_encode($rows);
    }

    public function check_duplicate() 
    {
        list($module, $model) = explode("/", $this->input->post('model'));
        $field = $this->input->post('field');
        $value = $this->input->post('value');
        
        $this->db->where($field, $value);

        $this->load->model($this->input->post('model'));

        if ($this->input->post('id')) {
            $this->db->where('id <>', $this->input->post('id'));
        }

        $total=$this->$model->find_count();

        if ($total == 0) 
            echo json_encode(array('success' => true));
        else
            echo json_encode(array('success' => false));
    }

    /**
    *
    * Convert Nepali Date into English Date
    *
    * @access  public
    * @param   null
    * @return  null
    */

    public function get_english_date()
    {
        $nepali_date = null;
        
        if ($this->input->post('nepali_date')) {
            $nepali_date = $this->input->post('nepali_date');
        }
        
        //HELPER FUNCTION
        get_english_date($nepali_date);
    }

     /**
    *
    * Convert  English Date into Nepali Date
    *
    * @access  public
    * @param   null
    * @return  null
    */

    public function get_nepali_date()
    {
        $english_date = null;
        
        if ($this->input->post('english_date')) {
            $english_date = $this->input->post('english_date');
        }
        
        //HELPER FUNCTION
        get_nepali_date($english_date);
    }

    protected function array_replace_null_by_zero(& $item, $key)
    {
        if ($item === null) {
            $item = 0;
        }
    }


    public function get_today_followup_json()
    {
        // $start_date = date("Y-m-d 00:00:00");
        $end_date   = date("Y-m-d 23:59:59");

        $this->load->model('customers/customer_followup_model');
        $this->customer_followup_model->_table = 'view_followup_schedule';
        
        // ACCESS LEVEL CHECK STARTS
        $is_showroom_incharge = NULL;
        $is_sales_executive = NULL;
    
        $dealer_list    = (is_dealer_incharge()) ? get_dealer_list() : NULL; 
        
        if (empty($dealer_list)) {
            $is_showroom_incharge = (is_showroom_incharge()) ? TRUE : NULL; 
            $is_sales_executive = (is_sales_executive()) ? TRUE : NULL; 
        }

        if(!empty($dealer_list)) {
            $this->db->where_in('dealer_id', $dealer_list);
            
        } elseif ($is_showroom_incharge) {
            $this->db->where('dealer_id', $this->session->userdata('employee')['dealer_id']);
        } elseif ($is_sales_executive) {
            $this->db->where('executive_id', $this->session->userdata('employee')['employee_id']);
        }

        //ENDS 

        //$this->db->where('followup_date_en >=', $start_date);
        $this->db->where('followup_date_en <=', $end_date);
        $this->db->where('followup_status', 'Open');

        $total=$this->customer_followup_model->find_count();

        // ACCESS LEVEL CHECK STARTS
        $is_showroom_incharge = NULL;
        $is_sales_executive = NULL;
    
        $dealer_list    = (is_dealer_incharge()) ? get_dealer_list() : NULL; 
        
        if (empty($dealer_list)) {
            $is_showroom_incharge = (is_showroom_incharge()) ? TRUE : NULL; 
            $is_sales_executive = (is_sales_executive()) ? TRUE : NULL; 
        }

        if(!empty($dealer_list)) {
            $this->db->where_in('dealer_id', $dealer_list);
            
        } elseif ($is_showroom_incharge) {
            $this->db->where('dealer_id', $this->session->userdata('employee')['dealer_id']);
        } elseif ($is_sales_executive) {
            $this->db->where('executive_id', $this->session->userdata('employee')['employee_id']);
        }

        //ENDS 

        paging('followup_date_en');

        //$this->db->where('followup_date_en >=', $start_date);
        $this->db->where('followup_date_en <=', $end_date);
        $this->db->where('followup_status', 'Open');
        $rows = $this->customer_followup_model->findAll();
        
        echo json_encode(array('success' => true, 'rows' =>$rows, 'total' => $total));     
    }
}