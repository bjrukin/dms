<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * PROJECT
 *
 * @package         PROJECT
 * @author          <AUTHOR_NAME>
 * @copyright       Copyright (c) 2016
 */

// ---------------------------------------------------------------------------

/**
 * MY_Router
 *
 * Extends the MX_Router class
 * 
 */

/* load the MX_Router class */
require APPPATH."libraries/MX/Router.php";

class MY_Router extends MX_Router 
{
	
}