<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * PROJECT
 *
 * @package         PROJECT
 * @author          <AUTHOR_NAME>
 * @copyright       Copyright (c) 2016
 */

// ---------------------------------------------------------------------------


if ( ! function_exists('paging'))
{
	function paging($default)
	{
		$CI = &get_instance();

		$input = $CI->input->get();
		
		$pagenum  = (isset($input['pagenum'])) ? $input['pagenum'] : 0;
		
		$pagesize  = (isset($input['pagesize'])) ? $input['pagesize'] : 100;
		
		$offset = $pagenum * $pagesize;

		$CI->db->limit($pagesize, $offset);

		//sorting
		if (isset($input['sortdatafield'])) {
			$sortdatafield = $input['sortdatafield'];
			$sortorder = (isset($input['sortorder'])) ? $input['sortorder'] :'asc';
			$CI->db->order_by($sortdatafield, $sortorder); 
		} else {
			$CI->db->order_by($default,'desc');
		}
		
	}
}

if ( ! function_exists('search_params'))
{
	function search_params()
	{
		$CI = &get_instance();

		$input = $CI->input->get();

		if (isset($input['filterscount'])) {
			$filtersCount = $input['filterscount'];
			if ($filtersCount > 0) {
				for ($i=0; $i < $filtersCount; $i++) {
					// get the filter's column.
					$filterDatafield 	= $input['filterdatafield' . $i];

					// get the filter's value.
					$filterValue 		=  $input['filtervalue' 	. $i];

					// get the filter's condition.
					$filterCondition 	= $input['filtercondition' . $i];

					// get the filter's operator.
					$filterOperator 	= $input['filteroperator' 	. $i];

					$operatorLike = 'LIKE';

					switch($filterCondition) {
						case "CONTAINS":
                            if (strtoupper($filterValue) == 'BLANK') {
                                // $CI->db->where("{$filterDatafield} IS EMPTY", null, false);
                            } else if(strtoupper($filterValue) == 'NULL') {
                                $CI->db->where("{$filterDatafield} IS NULL", null, false);
                            } else {
                                $CI->db->ilike($filterDatafield, $filterValue);
                            }
							break;
						case "DOES_NOT_CONTAIN":
							$CI->db->inot_like($filterDatafield, $filterValue);
							break;
						case "EQUAL":
							$CI->db->where($filterDatafield, $filterValue);
							break;
						case "GREATER_THAN":
							$CI->db->where($filterDatafield . ' >', $filterValue);
							break;
						case "LESS_THAN":
							$CI->db->where($filterDatafield . ' <', $filterValue);
							break;
						case "GREATER_THAN_OR_EQUAL":
							$CI->db->where($filterDatafield . ' >=', $filterValue);
							break;
						case "LESS_THAN_OR_EQUAL":
							$CI->db->where($filterDatafield . ' <=', $filterValue);
							break;
						case "STARTS_WITH":
							$CI->db->ilike($filterDatafield, $filterValue, 'after'); 
							break;
						case "ENDS_WITH":
							$CI->db->ilike($filterDatafield, $filterValue, 'before'); 
							break;
					}
				}
			}
		}
	}
}

if ( ! function_exists('get_english_date'))
{
	function get_english_date($nepali_date = null, $retType = 'json')
	{
		$CI = &get_instance();

		$date = null;
        $success = false;

        if ($nepali_date == null) {
			echo json_encode(array('success' => $success, 'date' => $date));
			exit;
		}

        $CI->load->library('nepali_calendar');

        list($y,$m,$d) = explode('-', $nepali_date);

        $converted_date = $CI->nepali_calendar->BS_to_AD($y,$m,$d);

        $date = date('Y-m-d',mktime(0,0,0, $converted_date['month'], $converted_date['date'], $converted_date['year']));

		if ($retType == 'json') {
			$success = true;
			echo json_encode(array('success' => $success, 'date' => $date));
		} else {
			return $date;
		}
	}

}

if ( ! function_exists('get_nepali_date'))
{
	function get_nepali_date($english_date = null, $retType = 'json')
	{
		$CI = &get_instance();

		$date = null;
        $success = false;

		if ($english_date == null) {
			echo json_encode(array('success' => $success, 'date' => $date));
			exit;
		}

        $CI->load->library('nepali_calendar');

        list($y,$m,$d) = explode('-', $english_date);

        $converted_date = $CI->nepali_calendar->AD_to_BS($y,$m,$d,'array');

        $date = $converted_date['year'] . '-' . sprintf("%02d", $converted_date['month'] ) . '-' . sprintf("%02d", $converted_date['date'] );

        if ($retType == 'json') {
        	$success = true;
        	echo json_encode(array('success' => $success, 'date' => $date));
        } else {
        	return $date;
        }
        
	}

}

if ( ! function_exists('get_current_calendar_year'))
{
	function get_current_calendar_year()
	{
		$CI = &get_instance();

		$CI->load->model('calendar_years/calendar_year_model');
        $id= 0;
        $row=$CI->calendar_year_model->get_by('active', TRUE);

        if($row){
            $id = $row->id;
        }

        return $id;
    }
}

if ( ! function_exists('internet_connection'))
{
	function internet_connection()
	{
	    $connected = @fsockopen("www.google.com", 80); 
	                                        //website, port  (try 80 or 443)
	    if ($connected){
	        $is_conn = true; //action when connected
	        fclose($connected);
	    }else{
	        $is_conn = false; //action in connection failure
	    }
	    return $is_conn;

	}
}

if ( ! function_exists('get_current_fiscal_year'))
{
	function get_current_fiscal_year()
	{
		$id 		 = null;
		$fiscal_year = null;

		$CI = &get_instance();
		$CI->load->model('fiscal_years/fiscal_year_model');
   		$CI->db->where('NOW()::date >= english_start_date');
		$CI->db->where('NOW()::date <= english_end_date');

		$fields = array();
		$fields[] = 'id';
		$fields[] = "(substr(nepali_start_date, 0, 5) || '-' || substr(nepali_end_date, 3, 2)) as fiscal_year";
   		
   		$record = $CI->fiscal_year_model->findAll(null, $fields);

   		if ($record){
   			$id	= $record[0]->id;
			$fiscal_year = $record[0]->fiscal_year;	
   		}
   		return array($id, $fiscal_year);
   		
   	}
}

if ( ! function_exists('get_current_user_details'))
{
	function get_current_user_details()
	{
		$CI = &get_instance();
		$CI->load->model('employees/employee_model');

		$CI->db->where('user_id', $CI->session->userdata('id'));

		$CI->employee_model->as_array();
		$record = $CI->employee_model->findAll(null, array('id as employee_id', 'dealer_id'));
   		
   		if ($record)
   		{
   			return $record[0];
   		}
   		return false;
	}
}

if ( ! function_exists('is_manager'))
{
	function is_manager()
	{
		$CI = &get_instance();
		$CI->load->model('users/user_group_model');

		$CI->db->where('user_id',  $CI->session->userdata('id'));
		$CI->db->where('group_id', MANAGER_GROUP);
	
		return ($CI->user_group_model->find_count() == 1) ? TRUE : FALSE;
	}
}

if ( ! function_exists('is_dealer_incharge'))
{
	function is_dealer_incharge()
	{
		$CI = &get_instance();
		$CI->load->model('users/user_group_model');

		$CI->db->where('user_id',  $CI->session->userdata('id'));
		$CI->db->where('group_id', DEALER_INCHARGE_GROUP);

		return ($CI->user_group_model->find_count() == 1) ? TRUE : FALSE;
	}
}

if ( ! function_exists('is_showroom_incharge'))
{
	function is_showroom_incharge()
	{
		$CI = &get_instance();
		$CI->load->model('users/user_group_model');

		$CI->db->where('user_id',  $CI->session->userdata('id'));
		$CI->db->where('group_id', SHOWROOM_INCHARGE_GROUP);

		return ($CI->user_group_model->find_count() > 0) ? TRUE : FALSE;
	}
}

if ( ! function_exists('is_sales_executive'))
{
	function is_sales_executive()
	{
		$CI = &get_instance();
		$CI->load->model('users/user_group_model');

		$CI->db->where('user_id',  $CI->session->userdata('id'));
		$CI->db->where('group_id', SALES_EXECUTIVE_GROUP);

		return ($CI->user_group_model->find_count() > 0) ? TRUE : FALSE;
	}
}

if ( ! function_exists('get_dealer_list'))
{
	function get_dealer_list()
	{
		$CI = &get_instance();
		$CI->load->model('dealers/dealer_model');

		$CI->db->where('incharge_id',  $CI->session->userdata('id'));

		$records = $CI->dealer_model->findAll(null, array('id'));

		$data = null;

		if ($records) {
			foreach ($records as $record) {
				$data[] = $record->id;
			}
		}
		return $data;
	}
}

/* End of file Installation_helper.php */
/* Location: ./application/helpers/paging_helper.php */