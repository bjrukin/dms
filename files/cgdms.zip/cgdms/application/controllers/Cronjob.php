<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * PROJECT
 *
 * @package         PROJECT
 * @author          <AUTHOR_NAME>
 * @copyright       Copyright (c) 2016
 */

// ---------------------------------------------------------------------------

/**
 * Cronjob
 *
 * Extends the MX_Controller class
 * 
 */

class Cronjob extends MX_Controller
{
	public function __construct() {
		parent::__construct();
	}
}