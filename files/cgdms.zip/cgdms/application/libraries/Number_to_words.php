<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

/**
* PROJECT
*
* @package         PROJECT
* @author          <AUTHOR_NAME>
* @copyright       Copyright (c) 2016
*/

// ---------------------------------------------------------------------------

/**
* Number_to_Words
*
*/
class Number_to_Words {

	public function convert_number($number) 
	{
		if (($number < 0) || ($number > 999999999)) 
		{
			throw new Exception("Number is out of range");
		}

		$Gn = floor($number / 1000000);
		/* Millions (giga) */
		
		$number -= $Gn * 1000000;
		$kn = floor($number / 1000);

		/* Thousands (kilo) */
		$number -= $kn * 1000;
		$Hn = floor($number / 100);

		/* Hundreds (hecto) */
		$number -= $Hn * 100;
		$Dn = floor($number / 10);

		/* Tens (deca) */
		$n = $number % 10;

		/* Ones */

		$res = "";

		if ($Gn) 
		{
			$res .= $this->convert_number($Gn) .  " Million";
		}

		if ($kn) 
		{
			$res .= (empty($res) ? "" : " ") .$this->convert_number($kn) . " Thousand";
		}

		if ($Hn) 
		{
			$res .= (empty($res) ? "" : " ") .$this->convert_number($Hn) . " Hundred";
		}

		$ones = array("", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eightteen", "Nineteen");
		$tens = array("", "", "Twenty", "Thirty", "Fourty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety");

		if ($Dn || $n) 
		{
			if (!empty($res)) 
			{
				$res .= " and ";
			}

			if ($Dn < 2) 
			{
				$res .= $ones[$Dn * 10 + $n];
			} else 
			{
				$res .= $tens[$Dn];

				if ($n) {
					$res .= " " . $ones[$n];
				}
			}
		}

		if (empty($res)) 
		{
			$res = "zero";
		}

		return $res;
	}

	public function convert_number_nepali($number) 
	{
		if (($number < 0) || ($number > 999999999)) 
		{
			throw new Exception("Number is out of range");
		}

		$Cc = floor($number / 10000000);

		$number -= $Cc * 10000000;
		$Lc = floor($number / 100000);
		/* Millions (giga) */
		
		$number -= $Lc * 100000;
		$kn = floor($number / 1000);

		/* Thousands (kilo) */
		$number -= $kn * 1000;
		$Hn = floor($number / 100);

		/* Hundreds (hecto) */
		$number -= $Hn * 100;
		$Dn = floor($number / 10);

		/* Tens (deca) */
		$n = $number % 10;

		/* Ones */

		$res = "";

		if ($Cc) 
		{
			$x = $this->convert_number_nepali($Cc);
			$res .= $x .  (($x != 'One') ? " Crores" : " Crore");
		}

		if ($Lc) 
		{
			$x = $this->convert_number_nepali($Lc);
			$res .= (empty($res) ? "" : " ") . $x .  (($x != 'One') ? " Lakhs" : " Lakh");
		}

		if ($kn) 
		{
			$x = $this->convert_number_nepali($Lc);
			$res .= (empty($res) ? "" : " ") . $x . (($x != 'One') ? " Thousands" : " Thousand");
		}

		if ($Hn) 
		{
			$x = $this->convert_number_nepali($Lc);
			$res .= (empty($res) ? "" : " ") . $x . (($x != 'One') ? " Hundreds" : " Hundred");
		}

		$ones = array("", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eightteen", "Nineteen");
		$tens = array("", "", "Twenty", "Thirty", "Fourty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety");

		if ($Dn || $n) 
		{
			if (!empty($res)) 
			{
				$res .= " and ";
			}

			if ($Dn < 2) 
			{
				$res .= $ones[$Dn * 10 + $n];
			} else 
			{
				$res .= $tens[$Dn];

				if ($n) {
					$res .= " " . $ones[$n];
				}
			}
		}

		if (empty($res)) 
		{
			$res = "zero";
		}

		return $res;
	}

	public function nepali_number_format($number, $precison = 2)
	{
		$number = strrev($number);

		$chunk0 = substr($number, 0,3);
		$chunk1 = substr($number, 3);

		$a = str_split($chunk1, 2);
		array_unshift($a, $chunk0);

		$format = "%0{$precison}d";
		return strrev(implode(",", $a)) . "." . sprintf($format, "");

	}

}

/* End of file Number_to_Words.php */
/* Location: ./application/libraries/Number_to_Words.php */