<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * PROJECT
 *
 * PACKAGE DESCRIPTION
 *
 * @package         PROJECT
 * @author          <AUTHOR_NAME>
 * @copyright       Copyright (c) 2016
 */

// ---------------------------------------------------------------------------

$lang['menu_home']		 		= 'Home';

$lang['menu_dashboard'] 		= 'Dashboard';
$lang['menu_system'] 			= 'System ';
$lang['menu_users'] 			= 'Users';
$lang['menu_groups'] 			= 'Groups';
$lang['menu_permissions'] 		= 'Permissions';
$lang['menu_group_permissions'] = 'Group Permissions';
$lang['menu_user_permissions'] 	= 'User Permissions';
$lang['menu_masters']			= 'Master Data';
$lang['menu_city_places']		= 'City Places';
$lang['menu_fiscal_years']		= 'Fiscal Years';
$lang['menu_dealers']			= 'Dealers';
$lang['menu_employees']			= 'Employees';
$lang['menu_crm']				= 'CRM';
$lang['menu_customers']			= 'Customers';
$lang['menu_schedules']			= 'Schedules';
$lang['menu_events']			= 'Events';
$lang['menu_vehicles']			= 'Vehicles';
$lang['menu_crm_reports'] 		= 'Reports';
$lang['menu_logistics'] 		= 'Logistics';
$lang['menu_plannings'] 		= 'Planning';
$lang['menu_monthly_plannings'] 	= 'Monthly Plannings';
$lang['menu_msil_orders']               = 'MSIL Order';
$lang['menu_dealer_order']              = 'Order';
$lang['menu_order_list']                = 'Dealer Order List';
$lang['menu_dispatch_records']          = 'Tracking';
$lang['menu_stock_records']             = 'Stock';
$lang['menu_stock_yard_stock_records']  = 'Stock-yard Stock';
$lang['menu_dealerstock__records']      = 'Dealer Stock';
$lang['menu_dealer_stock_view']         = 'Stock';
$lang['menu_dealer_retail_view']         = 'Retail';
$lang['menu_stock_report']              = 'Stock Report';